//
//  SVPinView.h
//  SVPinView
//
//  Created by Srinivas Vemuri on 27/02/18.
//  Copyright © 2018 Srinivas Vemuri. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for SVPinView.
FOUNDATION_EXPORT double SVPinViewVersionNumber;

//! Project version string for SVPinView.
FOUNDATION_EXPORT const unsigned char SVPinViewVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SVPinView/PublicHeader.h>


