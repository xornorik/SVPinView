import XCTest

import SVPinView_masterTests

var tests = [XCTestCaseEntry]()
tests += SVPinView_masterTests.allTests()
XCTMain(tests)
